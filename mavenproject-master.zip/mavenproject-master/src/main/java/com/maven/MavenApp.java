package com.maven;

public class MavenApp {
	public int square(int x) {
		return x * x;
	}
}
